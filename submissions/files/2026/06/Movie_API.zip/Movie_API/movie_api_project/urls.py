from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter

# Import all your views from their respective apps
from movies.views import MovieViewSet
from reviews.views import ReviewViewSet
from genres.views import GenreViewSet
from directors.views import DirectorViewSet

# One router to rule them all
router = DefaultRouter()
router.register(r'movies', MovieViewSet)
router.register(r'reviews', ReviewViewSet)
router.register(r'genres', GenreViewSet)
router.register(r'directors', DirectorViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    # This exposes all endpoints cleanly under /api/
    path('api/', include(router.urls)), 
]