from django.db import models
from movies.models import Movie

class Review(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    reviewer_name = models.CharField(max_length=100)
    comment = models.TextField(null=False)
    score = models.IntegerField(default=0, max_length=2)
    created_at = models.DateTimeField(auto_now_add=True)