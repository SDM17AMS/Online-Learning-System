from django.shortcuts import render
from rest_framework import viewsets
from .models import Genre
from .serializers import GenreSerializers

class GenreViewSet(viewsets.ModelViewSet):
    queryset = Genre.objects.all()
    serializer_class = GenreSerializers
