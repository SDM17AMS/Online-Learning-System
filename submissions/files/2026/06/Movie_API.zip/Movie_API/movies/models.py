from django.db import models
from genres.models import Genre
from directors.models import Director

class Movie(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(max_length=200)
    release_year = models.IntegerField(max_length=30)
    duration_minutes = models.IntegerField(max_length=30)
    rating = models.DecimalField(default=0, max_digits=3, decimal_places=1)
    is_available = models.BooleanField(default=True)
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    director = models.ForeignKey(Director, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title