from django.shortcuts import render
from rest_framework import viewsets
from .models import Movie
from .serializers import MovieSerializers

class MovieViewSet(viewsets.ModelViewSet):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializers
