from django.shortcuts import render
from rest_framework import viewsets
from .models import Director
from .serializers import DirectorSerializers

class DirectorViewSet(viewsets.ModelViewSet):
    queryset = Director.objects.all()
    serializer_class = DirectorSerializers
