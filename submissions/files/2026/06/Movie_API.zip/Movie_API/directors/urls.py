from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import DirectorViewSet

router = DefaultRouter()
router.register(r'directors', DirectorViewSet)

urlpatterns = [
    path('',include(router.urls))
]